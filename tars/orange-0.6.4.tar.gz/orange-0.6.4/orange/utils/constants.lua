local _M = {}

-- operators
_M.operator = {
    ["="] = "=",
    ["!="] = "!=",
    [">"] = ">",
    [">="] = ">=",
    ["<"] = "<",
    ["<="] = "<=",
    ["match"] = "match",
    ["not_match"] = "not_match",
}


return _M